import java.util.Scanner;
public class Input {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        byte x = sc.nextByte();
        System.out.println("The value of x is: "+x);
    }
}
