public class Final {
    public static void main(String [] args){
        final byte num1 = 125;
        System.out.println(num1);
        //num1+=1; will give error

        byte num2 = 100;
        System.out.println(++num2);
    }
}
