public class Variables {
    public static void main(String[] args){
        System.out.println("lets us learn about literals: ");
        byte byte_number = 25;
        long number1 = 24L;
        long number2 = 25l;
        char letter = 'A';
        float decimal = 23.5f;
        double num = 2.3;
        short short_num = 234;
        boolean value = true;
        String word = "Abhishek";

        System.out.println(byte_number);
        System.out.println(number1);
        System.out.println(number2);
        System.out.println(letter);
        System.out.println(decimal);
        System.out.println(num);
        System.out.println(short_num);
        System.out.println(value);
        System.out.println(word);
    }
}
